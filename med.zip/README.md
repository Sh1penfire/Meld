# Meld works on v147+!
I forgot to put this here after the content port, Meld is workin on the BE versions but there is currently a shortage of playable maps.

# Damit it's another one of those huge scope mindustry mod projects made by some guy in school isn't it.

As with most mods, Meld is more of a combat sim than a pure RTS/TDS/factory building mod.


If you're looking for masochistic gregory levels of tech, Meld may stil scratch that itch, but not to the same level as Complicatedustry. <br />
If you're looking for a mod where hundreds upon hundreds of enemies get vaporized, Meld can do that. <br />
If you're looking for a mod which encourages tactical positioning, unit micro and dynamic encounters, Meld does that too.


I've learned my lesson from working on huge scope Java mods, while I was still learning the language and dealing with burnout. I've decided to keep things "simple" this time.

What you'll find here might be surprising. <br />
"It's all Hjson?" <br />
"no, got a bit of python too" <br />
"Wh-"

I've used python to generate hjson for turret parts, feel free to look through the files if you're unsure.

# Onto the actual reason you're reading these obnoxiously long headers

I want to put a catchy slogan like "Meld puts the strategy in RTS". But no.

This isn't a very formal mod. It's a goofy experience which makes me want to chew my nails off when I lose to the damm bugs during playtesting.
The gamelpay style has pretty much solidified during the course of its months long development time, incorperating or revising elements that I personally found fun about Mindustry like the core unit.

Meld is **currently** a unique blend of: <br />
 - Pure PVE-focused design <br />
 - Tower defense-like design for enemy units (I love it when an enemy unit can just walk up to my tower and disable it, so now there's a unit that shoots force projectors. lmao.) <br />
 - A yeetening of tiers (good riddance!) <br />
 - units designed to fill niches instead of fill reconstructor space. <br />
 - 5\. second. units. <br />
 - Proper integration of status effects, knockback and drag into the moment-to-moment gameplay <br />
 - Purposeful design involving armor for both buildings and units <br />
 - Instakills <br />
 - Balance tipped towards player expression and strategy rather than keeping things fair <br />
 - Unique cross-biome progression <br />
 - Core units with stupidly powerful guns/abilities called Commanders <br />
 - Environmental props that give resources <br />
 - Refrences to other games I've played and enjoyed <br />
 - Fishes. A lot of fishes. Don't forget the bugs. <br />
 - Lots more that sleep-deprived me decided not to put on here for fear of making this section too lengthy. Go play the mod ya goob.

This is **all in the mod, right now**, and is **available to be played, r i g h t  n o w**.

# Where can I keep up with the mod's development
I post the ocasional video on youtube, though im more active in the mod's fourm post on the Mindustry discord server.
I've also started a server for the mod on discord. It's quite new so there isn't much there, but im open to talk about dev.
Invites are currently on hold, DM me if you'd like to join. You can find me through the Mindustry discord server.

Im currently working towards finishing off spritework for the storm planes, then adding more maps.
Mapping help would be much appreciated, theres a lot of maps to make ;~:
